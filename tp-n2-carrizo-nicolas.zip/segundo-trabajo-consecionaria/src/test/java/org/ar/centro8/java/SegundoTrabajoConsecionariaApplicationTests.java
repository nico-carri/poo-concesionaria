package org.ar.centro8.java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SegundoTrabajoConsecionariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
