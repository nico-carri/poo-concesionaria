package org.ar.centro8.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SegundoTrabajoConsecionariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SegundoTrabajoConsecionariaApplication.class, args);
	}

}
