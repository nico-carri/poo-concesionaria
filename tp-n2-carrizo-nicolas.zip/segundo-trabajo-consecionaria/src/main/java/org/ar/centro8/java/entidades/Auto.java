package org.ar.centro8.java.entidades;

import org.ar.centro8.java.logica.ConcesionariaLogica;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Auto extends Vehiculo {

    private int puertas;

    // Constructor completo que llama al constructor padre
    public Auto(String marca, String modelo, double precio, int puertas) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    //sobreescribo para que muestre cant. de puertas
    @Override
    public String toString() {
        return  "Marca: " + getMarca() +
                " // Modelo: " + getModelo() +
                " // Puertas: " + getPuertas() +
                " // Precio: " + ConcesionariaLogica.formatearPrecio(getPrecio());
    }


}
