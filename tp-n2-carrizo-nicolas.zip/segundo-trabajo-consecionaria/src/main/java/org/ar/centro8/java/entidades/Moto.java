package org.ar.centro8.java.entidades;

import org.ar.centro8.java.logica.ConcesionariaLogica;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Moto extends Vehiculo {

    private String cilindrada;

       // Constructor completo que llama al constructor padre
    public Moto(String marca, String modelo, double precio, String cilindrada) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }

    //sobreescribo para que muestre marca, modelo, precio,
    //cilindrada y el precio formateado según lo pide la consigna.
    @Override
    public String toString() {
        return  "Marca: " + getMarca() +
                " // Modelo: " + getModelo() +
                " // Cilindrada: " + getCilindrada() +
                " // Precio: " + ConcesionariaLogica.formatearPrecio(getPrecio());
}


}
