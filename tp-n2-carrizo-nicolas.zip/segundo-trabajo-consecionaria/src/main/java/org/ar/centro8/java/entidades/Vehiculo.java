package org.ar.centro8.java.entidades;

import org.ar.centro8.java.logica.ConcesionariaLogica;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public  abstract class Vehiculo implements Comparable <Vehiculo> {

    private String marca;
    private String modelo;
    private double precio;

    //método para que Auto y Moto lo reescriban con su respectiva descripción.
    @Override
    public String toString() {
    return "Marca: " + getMarca() + 
           " // Modelo: " + getModelo() + 
           " // Precio: " + ConcesionariaLogica.formatearPrecio(getPrecio());
    }

    //sobreescribo el método compareTo que deriva de la interfaz Comparable<T> 
    //y así poder comprar los vehículos
    @Override
    public int compareTo(Vehiculo otroVehiculo) {
        String thisVehiculo = this.getMarca() + " // " + this.getModelo() + " // " + this.getPrecio();
        String VehiculoOtro = otroVehiculo.getMarca() + " // " + otroVehiculo.getModelo() + " // " + otroVehiculo.getPrecio();
        return thisVehiculo.compareTo(VehiculoOtro);
    }

    
}
