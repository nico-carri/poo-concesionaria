package org.ar.centro8.java.logica;

import org.ar.centro8.java.entidades.Auto;
import org.ar.centro8.java.entidades.Moto;
import org.ar.centro8.java.entidades.Vehiculo;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ConcesionariaLogica {

    public static List<Vehiculo> cargarListaVehiculos() {
        List<Vehiculo> vehiculos = new ArrayList<>();
        vehiculos.add(new Auto("Peugeot", "206", 200000.0, 4));
        vehiculos.add(new Moto("Honda", "Titan", 60000.0, "125c"));
        vehiculos.add(new Auto("Peugeot", "208", 250000.0, 5));
        vehiculos.add(new Moto("Yamaha", "YBR", 80500.5, "160c"));
        return vehiculos;
    }

    //método para mostrar la lsita tal cual fue cargada
    public static void mostrarVehiculos(List<Vehiculo> vehiculos) {
    vehiculos.forEach(System.out::println);
    }

    //método para obtener el vehículo más caro
    public static Vehiculo calcularMasCaro(List<Vehiculo> vehiculos) {
        return vehiculos
                        .stream()
                        .max(Comparator.comparing(Vehiculo::getPrecio))
                        .get();
    }

    //método para obtener el vehículo más barato
    public static Vehiculo calcularMasBarato(List<Vehiculo> vehiculos) {
        return vehiculos
                        .stream()
                        .min(Comparator.comparing(Vehiculo::getPrecio))
                        .get();
    }

    //método para obtener una lista con los vehículos que contengan la letra pasado como parametro en el modelo
    public static List<Vehiculo> buscarLetra(List<Vehiculo> vehiculos, String letra) {
        return vehiculos.stream()
                        .filter(v -> v.getModelo().toUpperCase().contains(letra.toUpperCase()))
                        .toList();
    }


    //método para obtener una lista ordenada de mayor a menor según el precio
    public static List<Vehiculo> ordenarPrecioDesc(List<Vehiculo> vehiculos) {
    return vehiculos.stream()
                    .sorted(Comparator.comparing(Vehiculo::getPrecio).reversed())
                    .toList();
    }

    //método para ordenar de forma natural
    public static List<Vehiculo> ordenarNatural(List<Vehiculo> vehiculos) {
        return vehiculos.stream()
                        .sorted()
                        .toList();
    }

    // Método para formatear precio, es decir, agregar $
    // y reemplazar las comas por puntos y los puntos por comas 
    public static String formatearPrecio(double precio) {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setDecimalSeparator(',');  // asi la coma separa decimal
        symbols.setGroupingSeparator('.'); // y el punto separa miles

        DecimalFormat df = new DecimalFormat("#,##0.00", symbols);
        return "$" + df.format(precio);
    }

}
