package org.ar.centro8.java.test;

import java.util.List;

import org.ar.centro8.java.entidades.Vehiculo;
import org.ar.centro8.java.logica.ConcesionariaLogica;

public class TestConcesionaria {
    public static void main(String[] args) {

        
        //cargo la lista de vehículos 
        List<Vehiculo> vehiculos = ConcesionariaLogica.cargarListaVehiculos();

        //llamo al método mostrarVehiculos para imprimir la lista tal cual fue cargada
        ConcesionariaLogica.mostrarVehiculos(vehiculos);

        System.out.println("\n=============================");
        //muestro el vehículo más caro
        Vehiculo masCaro = ConcesionariaLogica.calcularMasCaro(vehiculos);
        System.out.println("\nVehículo más caro: " + masCaro.getMarca() + " " + masCaro.getModelo());

        //muestro el vehículo más barato
        Vehiculo masBarato = ConcesionariaLogica.calcularMasBarato(vehiculos);
        System.out.println("Vehículo más barato: " + masBarato.getMarca() + " " + masBarato.getModelo());

        //muestro el/los vehículos cuyo modelo contenga la letra 'Y'
        //primero guardo el resutlado en una lista del tipo Vehiculos y luego la recorro
        List<Vehiculo> resultado = ConcesionariaLogica.buscarLetra(vehiculos, "Y");

        System.out.println("Vehículo que contiene en el modelo la letra 'Y':");
        resultado.forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo() + " " + ConcesionariaLogica.formatearPrecio(v.getPrecio())));


        System.out.println("\n=============================");

        //muestro vehículos ordenados por precio descendente
        System.out.println("\nVehículos ordenados por precio de mayor a menor:");
        ConcesionariaLogica.ordenarPrecioDesc(vehiculos).forEach(v -> 
        System.out.println(" " + v.getMarca() + " " + v.getModelo())
        );

        System.out.println("\n=============================");

        //muestro vehículos ordenados naturalmente (marca, modelo, precio)
        System.out.println("\nVehículos ordenados naturalmente (marca, modelo, precio):");
        ConcesionariaLogica.ordenarNatural(vehiculos).forEach(System.out::println);
        

    }

}
